﻿using office_equipment_rental.Windows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace office_equipment_rental.Classes
{
    public class Sing_Reg
    {
        static businessEntities DB = new businessEntities();
        public Utils util = new Utils();

        public bool SingIn(string login, string pass)
        {
            if (DB.Users.Where(r => r.Login == login &&
                                r.Password == pass).Count() > 0)
                return true;
            MessageBox.Show("Неверный логин или пароль", "Ошибка");
            return false;
        }

        public bool CheckRegistered(string login)
        {
            if (DB.Users.Where(r => r.Login == login).Count() == 0)
                return true;
            MessageBox.Show("Пользователь с таким логином уже есть", "Ошибка");
            return false;
        }

        public bool Reg(string login, string pass, string name, DateTime data, bool admin)
        {
            if (CheckRegistered(login))
            {
                Users user = new Users(login, pass, name, data, admin);
                DB.Users.Add(user);
                DB.SaveChanges();
                return true;
            }
            return false;
        }
    }
}
