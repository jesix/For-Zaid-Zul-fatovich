﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace office_equipment_rental.Windows
{
    public class Utils
    {
        businessEntities db = new businessEntities();
        public Utils()
        {
        }

        private string retString(Object Element)
        {
            if (Element is TextBox)
                return ((TextBox)Element).Text;
            else if (Element is PasswordBox)
                return ((PasswordBox)Element).Password;
            return null;
        }

        public bool CheckEmptyMas(Grid one)
        {
            foreach (var item in one.Children)
                if (CheckEmpty(retString(item)))
                    return true;
            return false;
        }

        public bool CheckEmpty(string str)
        {
            if (str != "")
                return false;
            MessageBox.Show("Пустые поля", "Ошибка");
            return true;
        }

        public Users find_user(string login)
        {
            foreach (var item in db.Users)
            {
                if (item.Login == login)
                    return (Users)item;
            }
            return null;
        }

        public bool is_admin(string login)
        {
            if (find_user(login).is_Admin)
                return true;
            return false;
        }


    }
}
