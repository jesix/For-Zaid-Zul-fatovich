﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace office_equipment_rental.Windows
{
    /// <summary>
    /// Логика взаимодействия для Win_device.xaml
    /// </summary>
    /// 

    public partial class Win_device : Window
    {
        string title;
        Device device;
        businessEntities db = new businessEntities();
        Utils util  = new Utils();
        string user;
        public Win_device(string Title, string user)
        {
            InitializeComponent();
            this.title = Title;
            device = find_Device(title);
            this.user = user;
            Title_device.Text = device.Title;
            Discr.Text = device.Descr;
            Price.Text = device.Price.ToString();
            Image_device.Source = BitmapFrame.Create(get_image(device.Image));
            if (util.is_admin(user))
                admin.Visibility = Visibility.Visible;
        }

        public BitmapImage get_image(byte[] source)
        {
            byte[] bytes = source;
            BitmapImage bitmap = new BitmapImage();
            bitmap.BeginInit();
            bitmap.StreamSource = new MemoryStream(bytes);
            bitmap.EndInit();
            return bitmap;
        }

        public Device find_Device(string Title)
        {
            foreach (var item in db.Device)
                if(item.Title == Title)
                    return (Device)item;
            return null;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Win_decoration win = new Win_decoration(title, user);
            win.Show();
            this.Close();
        }

        private void Label_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Win_info win = new Win_info(user);
            win.Show();
            this.Close();
        }

        private void Label_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            Win_services win = new Win_services(user);
            win.Show();
            this.Close();
        }

        private void admin_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Win_add win = new Win_add(user);
            win.Show();
            this.Close();
        }
    }
}
