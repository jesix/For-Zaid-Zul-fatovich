﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace office_equipment_rental.Windows
{
    /// <summary>
    /// Логика взаимодействия для Win_services.xaml
    /// </summary>
    /// 

    public class MethodToValueConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            byte[] bytes = (byte[])value;
            BitmapImage bitmap = new BitmapImage();
            bitmap.BeginInit();
            bitmap.StreamSource = new MemoryStream(bytes);
            bitmap.EndInit();
            return bitmap;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException("MethodToValueConverter can only be used for one way conversion.");
        }
    }

    public partial class Win_services : Window
    {
        string user;
        Utils util = new Utils();
        public Win_services(string user)
        {
            InitializeComponent();
            var currentDevice = businessEntities.GetContext().Device.ToList();
            ListDevice.ItemsSource = currentDevice;
            this.user = user;   
            if (util.is_admin(user))
                admin.Visibility = Visibility.Visible;
        }
        
        private void Label_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Win_info win = new Win_info(user);
            win.Show();
            this.Close();
        }

        private void admin_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Win_add win = new Win_add(user);
            win.Show();
            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            object tag = ((Button)e.OriginalSource).Tag;
            MessageBox.Show((string)tag);
            Win_device win = new Win_device((string)tag, user);
            win.Show();
            this.Close();
        }
    }
}
