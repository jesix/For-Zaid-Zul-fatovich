﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace office_equipment_rental.Windows
{
    /// <summary>
    /// Логика взаимодействия для Win_decoration.xaml
    /// </summary>
    public partial class Win_decoration : Window
    {
        string user;
        string device;
        Utils util = new Utils();
        businessEntities db = new businessEntities();

        public Win_decoration(string device, string user)
        {
            InitializeComponent();
            this.user = user;
            this.device = device;
            if (util.is_admin(user))
                admin.Visibility = Visibility.Visible;
        }

        private void Label_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Win_info win = new Win_info(user);
            win.Show();
            this.Close();
        }

        private void Label_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            Win_services win = new Win_services(user);
            win.Show();
            this.Close();
        }

        private void admin_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Win_add win = new Win_add(user);
            win.Show();
            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (!util.CheckEmptyMas(grid))
            {
                int id_device = 0;
                int id_user = 0;
                foreach (var item in db.Users)
                    if (item.Login == user)
                        id_user = item.id;
                foreach (var item in db.Device)
                    if (item.Title == device)
                        id_device = item.id;
                if (id_device != 0 && id_user != 0)
                {
                    MessageBox.Show("оформленно");
                    Bid bid = new Bid(id_user, id_device);
                    db.Bid.Add(bid);
                    db.SaveChanges();
                    Win_info win = new Win_info(user);
                    win.Show();
                    this.Close();
                }
            }
        }
    }
}
