﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace office_equipment_rental.Windows
{
    /// <summary>
    /// Логика взаимодействия для Win_info.xaml
    /// </summary>

    public partial class Win_info : Window
    {
        string user;
        Utils util = new Utils();
        public Win_info(string user)
        {
            InitializeComponent();
            this.user = user;
            if (util.is_admin(user))
                admin.Visibility = Visibility.Visible;
        }

        private void Label_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Win_services win = new Win_services(user);
            win.Show();
            this.Close();
        }

        private void Label_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            Win_add win = new Win_add(user);
            win.Show();
            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Win_services win = new Win_services(user);
            win.Show();
            this.Close();
        }
    }
}
