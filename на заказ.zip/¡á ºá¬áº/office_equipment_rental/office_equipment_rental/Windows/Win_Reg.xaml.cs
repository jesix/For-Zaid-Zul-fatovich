﻿using office_equipment_rental.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace office_equipment_rental.Windows
{
    /// <summary>
    /// Логика взаимодействия для Win_Reg.xaml
    /// </summary>
    public partial class Win_Reg : Window
    {
        Utils util = new Utils(); 
        Sing_Reg db = new Sing_Reg();
        public Win_Reg()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Win_authoriz win = new Win_authoriz();
            win.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (!util.CheckEmptyMas(grid) && 
                db.Reg(Login.Text, Pass.Text, Name.Text, Convert.ToDateTime(Data.Text), (bool)Admin.IsChecked))
            {
                Win_info win = new Win_info(Login.Text);
                win.Show();
                this.Close();
                MessageBox.Show("Зарегистрирован");
            }
            else
                MessageBox.Show("Такой пользователь есть");
        }
    }
}
