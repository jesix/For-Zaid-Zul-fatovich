﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace office_equipment_rental.Windows
{
    /// <summary>
    /// Логика взаимодействия для Win_add.xaml
    /// </summary>
    public partial class Win_add : Window
    {
        businessEntities db = new businessEntities();
        string filename;
        string user;
        public Win_add(string user)
        {
            InitializeComponent();
            this.user = user;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            byte[] buffer;
            buffer = File.ReadAllBytes(filename);

            try
            {
                Device man = new Device(Title.Text, Discr.Text ,Convert.ToDouble(Price.Text), buffer);
                db.Device.Add(man);
                db.SaveChanges();
                MessageBox.Show("Отправлено");
            }
            catch (Exception)
            {
                MessageBox.Show("Ошибка");
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.FileName = "Image"; // Default file name
            dlg.DefaultExt = ".png"; // Default file extension
            dlg.Filter = "Text documents (.png; .jpg ) | *.png; *.jpg"; // Filter files by extension

            // Show open file dialog box
            Nullable<bool> result = dlg.ShowDialog();

            if (result == true)
            {
                // Open document
                filename = dlg.FileName;
                image_device.Source = BitmapFrame.Create(new Uri(filename));
            }
        }

        private void admin_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Win_add win = new Win_add(user);
            win.Show();
            this.Close();
        }

        private void Label_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Win_info win = new Win_info(user);
            win.Show();
            this.Close();
        }

        private void Label_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            Win_services win = new Win_services(user);
            win.Show();
            this.Close();
        }
    }
}
