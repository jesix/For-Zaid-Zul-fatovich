﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using office_equipment_rental.Classes;
using office_equipment_rental.Windows;
using System;

namespace TestProg
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Is_admin_test()
        {
            Utils util = new Utils();
            Assert.IsTrue(util.is_admin("1"));
            Assert.IsFalse(util.is_admin("2"));
        }

        [TestMethod]
        public void Check_empty_test()
        {
            Utils util = new Utils();
            Assert.IsTrue(util.CheckEmpty(""));
            Assert.IsFalse(util.CheckEmpty("2"));
        }

        [TestMethod]
        public void SingIn()
        {
            Sing_Reg sr = new Sing_Reg();

            Assert.IsTrue(sr.SingIn("1", "1"));
            Assert.IsFalse(sr.SingIn("0", "0"));
        }

        [TestMethod]
        public void CheckRegistered()
        {
            Sing_Reg sr = new Sing_Reg();

            Assert.IsTrue(sr.CheckRegistered("0"));
            Assert.IsFalse(sr.CheckRegistered("1"));
        }
    }
}
